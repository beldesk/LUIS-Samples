# angular-material-dashboard-setup

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-material-dashboard-setup)

![Screenshot](https://raw.githubusercontent.com/eneajaho/angular-material-dashboard-setup/master/scr.png)
